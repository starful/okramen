import os, json, frontmatter, markdown
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT_DIR = os.path.join(BASE_DIR, 'app', 'content')
OUTPUT_PATH = os.path.join(BASE_DIR, 'app', 'static', 'json', 'ramen_data.json')

def main():
    print("🔨 Building OKRamen Production Data...")
    ramens = []
    
    if not os.path.exists(CONTENT_DIR): return

    for filename in os.listdir(CONTENT_DIR):
        if not filename.endswith('.md'): continue
        
        try:
            with open(os.path.join(CONTENT_DIR, filename), 'r', encoding='utf-8') as f:
                post = frontmatter.load(f)
                
                # 카테고리 정규화
                cats = post.get('categories', [])
                if isinstance(cats, str): cats = [c.strip() for c in cats.split(',')]
                
                # 요약문 (없으면 본문에서 추출)
                summary = post.get('summary', '')
                if not summary:
                    summary = post.content[:200].replace('\n', ' ') + '...'

                ramens.append({
                    "id": filename.replace('.md', ''),
                    "lang": post.get('lang', 'en'),
                    "title": post.get('title', 'Untitled'),
                    "lat": post.get('lat'),
                    "lng": post.get('lng'),
                    "categories": cats,
                    "thumbnail": post.get('thumbnail', '/static/images/default.jpg'),
                    "address": post.get('address', 'Japan'),
                    "published": str(post.get('date', datetime.now().strftime('%Y-%m-%d'))),
                    "summary": summary,
                    "link": f"/ramen/{filename.replace('.md', '')}"
                })
        except Exception as e:
            print(f"❌ Skip {filename}: {e}")

    # 최신순 정렬
    ramens.sort(key=lambda x: x['published'], reverse=True)

    final_json = {
        "last_updated": datetime.now().strftime("%Y.%m.%d"),
        "total_count": len(ramens),
        "ramens": ramens
    }

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(final_json, f, ensure_ascii=False, indent=2)

    print(f"🎉 Success: {len(ramens)} entries compiled.")

if __name__ == "__main__":
    main()