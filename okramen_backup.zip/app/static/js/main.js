/**
 * OKRamen Main Engine
 * Handles Data Fetching, 2-Tier Filtering, and Google Maps Advanced Markers
 */

const OKRamenApp = {
    // --- State Management ---
    state: {
        allData: [],
        filteredData: [],
        currentLang: 'en',
        currentFlavor: 'all',
        currentVibe: 'all',
        map: null,
        markers: []
    },

    // --- Initialization ---
    async init() {
        console.log("🚀 OKRamen App Starting...");
        this.bindEvents();
        await this.fetchData();
        this.render();
    },

    // --- API Data Fetching ---
    async fetchData() {
        try {
            const response = await fetch('/api/items');
            const json = await response.json();
            this.state.allData = json.ramens || [];
            this.updateStatusBar(json.last_updated, this.state.allData.length);
        } catch (e) {
            console.error("❌ Data fetch failed", e);
        }
    },

    // --- UI Update: Status Bar ---
    updateStatusBar(date, count) {
        const dateEl = document.getElementById('last-updated-date');
        const countEl = document.getElementById('total-onsens');
        if (dateEl) dateEl.innerText = date;
        if (countEl) countEl.innerText = count;
    },

    // --- Filtering Logic (The Core) ---
    applyFilters() {
        const { allData, currentLang, currentFlavor, currentVibe } = this.state;

        this.state.filteredData = allData.filter(item => {
            // 1. Language Check
            const langMatch = item.lang === currentLang;
            
            // 2. Flavor Check (Cross-language support using includes)
            const flavorMatch = currentFlavor === 'all' || 
                (item.categories && item.categories.some(cat => 
                    cat.toLowerCase().replace(/\s/g, '') === currentFlavor.toLowerCase()));

            // 3. Vibe Check
            const vibeMatch = currentVibe === 'all' || 
                (item.categories && item.categories.some(cat => 
                    cat.toLowerCase().replace(/\s/g, '') === currentVibe.toLowerCase()));

            return langMatch && flavorMatch && vibeMatch;
        });

        console.log(`🔍 Filtered: ${this.state.filteredData.length} items`);
    },

    // --- Rendering: UI & Map ---
    render() {
        this.applyFilters();
        this.renderList();
        this.renderMarkers();
        this.updateFilterBadges();
    },

    renderList() {
        const container = document.getElementById('onsen-list');
        if (!container) return;
        
        container.innerHTML = this.state.filteredData.length > 0 
            ? this.state.filteredData.map(item => this.createCardHTML(item)).join('')
            : `<div class="no-results">No Ramen shops found matching your criteria.</div>`;
    },

    createCardHTML(item) {
        return `
            <article class="onsen-card">
                <a href="${item.link}" class="card-thumb-link">
                    <img src="${item.thumbnail}" class="card-thumb" 
                         loading="lazy" onerror="this.src='https://placehold.co/600x450?text=Ramen+Image'">
                </a>
                <div class="card-content">
                    <div class="card-meta">📍 ${item.address}</div>
                    <h3 class="card-title"><a href="${item.link}">${item.title}</a></h3>
                    <p class="card-summary">${item.summary}</p>
                    <div class="card-footer">
                        <span class="card-tags">${item.categories.map(c => `#${c}`).join(' ')}</span>
                        <a href="${item.link}" class="card-btn">Explore →</a>
                    </div>
                </div>
            </article>`;
    },

    // --- Google Maps Handling ---
    renderMarkers() {
        if (!this.state.map) return;

        // Clear old markers
        this.state.markers.forEach(m => m.setMap(null));
        this.state.markers = [];

        this.state.filteredData.forEach(item => {
            if (!item.lat || !item.lng) return;

            const marker = new google.maps.Marker({
                position: { lat: parseFloat(item.lat), lng: parseFloat(item.lng) },
                map: this.state.map,
                title: item.title,
                animation: google.maps.Animation.DROP
            });

            const infoWindow = new google.maps.InfoWindow({
                content: `<div class="map-info"><strong>${item.title}</strong><br><a href="${item.link}">View Detail</a></div>`
            });

            marker.addListener("click", () => infoWindow.open(this.state.map, marker));
            this.state.markers.push(marker);
        });
    },

    // --- Badge Counter Update ---
    updateFilterBadges() {
        const langData = this.state.allData.filter(i => i.lang === this.state.currentLang);
        
        // Update all buttons with IDs like 'count-tonkotsu', 'count-vibe-solo' 등
        document.querySelectorAll('.count-badge').forEach(badge => {
            const id = badge.id; // e.g., count-tonkotsu
            const theme = id.replace('count-', '').replace('vibe-', '');
            
            const count = (theme === 'all') 
                ? langData.length 
                : langData.filter(i => i.categories.some(c => c.toLowerCase().replace(/\s/g, '') === theme)).length;
            
            badge.innerText = count;
        });
    },

    // --- Event Listeners ---
    bindEvents() {
        // Language Switch
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.state.currentLang = e.target.dataset.lang;
                this.render();
            });
        });

        // Flavor/Vibe Buttons
        document.querySelectorAll('.theme-button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = e.target.closest('.theme-button');
                const group = target.parentElement.dataset.group;
                
                target.parentElement.querySelectorAll('.theme-button').forEach(b => b.classList.remove('active'));
                target.classList.add('active');

                if (group === 'flavor') this.state.currentFlavor = target.dataset.theme;
                else this.state.currentVibe = target.dataset.theme;
                
                this.render();
            });
        });
    }
};

// Google Map Callback
window.initMap = function() {
    const el = document.getElementById("map");
    if (!el) return;
    OKRamenApp.state.map = new google.maps.Map(el, {
        center: { lat: 35.6895, lng: 139.6917 },
        zoom: 11,
        styles: [{ featureType: "poi", elementType: "labels", stylers: [{ visibility: "off" }] }]
    });
    OKRamenApp.init();
};